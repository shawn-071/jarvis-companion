# JARVIS Companion

This folder contains the JARVIS glasses field guide and its Streamlit Community Cloud entry point.

## Deploy

1. Put the contents of this folder at the root of a GitHub repository.
2. In Streamlit Community Cloud, create an app from that repository and choose `app.py` as the entry point.
3. After deployment, set the app's sharing access to public if it is not already public.

The app keeps the interactive HTML guide, embedded logo, downloadable 3D model, and its material file together.
